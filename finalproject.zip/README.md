# 3110 Final Project: 

## Contributors:
### Team Name: Big Bactrian Camels
Iram Liu il233\
Joanna Lin jl2748\
Jeffrey Xiang jjx5

# Description: 
This is a terminal based implementation of Go-Fish for our final project in our Functional Programming class (CS 3110). 
